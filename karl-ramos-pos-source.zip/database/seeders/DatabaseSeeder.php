<?php

namespace Database\Seeders;

use App\Models\Customer;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        User::updateOrCreate([
            'email' => 'admin@pos.test',
        ], [
            'name' => 'Karl Ramos',
            'password' => 'password',
        ]);

        $customers = [
            ['customer_code' => 'CUS-1001', 'name' => 'Ana Santos', 'email' => 'ana@example.com', 'phone' => '0917 555 0101', 'address' => 'Quezon City', 'status' => 'active'],
            ['customer_code' => 'CUS-1002', 'name' => 'Miguel Reyes', 'email' => 'miguel@example.com', 'phone' => '0918 555 0102', 'address' => 'Makati City', 'status' => 'active'],
            ['customer_code' => 'CUS-1003', 'name' => 'Jamie Cruz', 'email' => 'jamie@example.com', 'phone' => '0919 555 0103', 'address' => 'Pasig City', 'status' => 'inactive'],
        ];

        foreach ($customers as $customer) {
            Customer::updateOrCreate(
                ['customer_code' => $customer['customer_code']],
                $customer
            );
        }
    }
}
