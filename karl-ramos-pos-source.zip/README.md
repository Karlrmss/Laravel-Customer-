# Karl POS Account Console

A secure customer and user account management system for a point-of-sale application, built with Laravel resource controllers and Laravel Breeze authentication.

**Developer:** Karl Ramos  
**Course outcome:** Apply advanced web development principles in creating, debugging, validating, and securing database-backed web applications.

## Features

- Customer account CRUD using one `Route::resource()` registration
- User account CRUD using one `Route::resource()` registration
- Conventional `index`, `create`, `store`, `show`, `edit`, `update`, and `destroy` controller methods
- Laravel Breeze login, registration, password reset, and profile scaffolding
- `auth` middleware on the dashboard and both resource route groups
- Server-side validation and CSRF protection on every modifying form
- Password hashing through Laravel's built-in `hashed` model cast
- Search and pagination for customer and user records
- Self-deletion protection for the account currently signed in
- Responsive, self-contained interface with no Node.js build required
- SQLite configuration and demonstration seed data
- Feature tests for Breeze authentication, resource access control, CRUD, and password security

## Requirements

- PHP 8.2 or newer
- Composer 2
- PHP extensions normally required by Laravel, including PDO and SQLite

## Quick setup

```bash
git clone <your-repository-url>
cd karl-ramos-pos
composer setup
composer dev
```

Open `http://127.0.0.1:8000`.

The `composer setup` command installs dependencies, creates `.env`, generates the application key, creates the SQLite file, runs all migrations, and seeds demonstration data.

## Manual setup

```bash
composer install
cp .env.example .env
php artisan key:generate
touch database/database.sqlite
php artisan migrate --seed
php artisan serve
```

No `npm install` or front-end build is required. The application uses the versioned stylesheet at `public/css/app.css`.

## Demo account

| Field | Value |
| --- | --- |
| Email | `admin@pos.test` |
| Password | `password` |

The demo credentials are intended for local assessment only. Change or remove them before deploying publicly.

## Resource routes

The protected routes are intentionally concise:

```php
Route::middleware('auth')->group(function () {
    Route::resource('customers', CustomerController::class);
    Route::resource('users', UserController::class);
});
```

Each resource expands to the seven conventional actions required by the exercise. Run `php artisan route:list` to inspect the generated routes and middleware.

## Access-control verification

1. Sign out or open a private browser window.
2. Visit `/customers`, `/customers/create`, `/users`, or `/users/create`.
3. Confirm that Laravel redirects the request to `/login`.
4. Sign in with the demo account.
5. Visit the same routes and confirm that the pages load normally.

This behavior is also automated in `tests/Feature/ResourceAccessTest.php`.

## Run tests

```bash
composer test
```

The suite covers Breeze's authentication behavior, account profile operations, logged-out redirects, logged-in access, customer CRUD, secure user creation, and current-user deletion protection.

## Main project structure

```text
app/
├── Http/Controllers/
│   ├── Auth/                 # Breeze authentication controllers
│   ├── CustomerController.php
│   └── UserController.php
├── Models/
│   ├── Customer.php
│   └── User.php
database/
├── migrations/              # Users, sessions/cache, jobs, customers
└── seeders/DatabaseSeeder.php
resources/views/
├── auth/                    # Breeze authentication screens
├── customers/               # Customer resource views
├── users/                   # User resource views
└── dashboard.blade.php
routes/
├── auth.php                 # Breeze routes
└── web.php                  # Protected resource routes
tests/Feature/
└── ResourceAccessTest.php
```

## Deployment checklist

- Set `APP_ENV=production`, `APP_DEBUG=false`, and the public `APP_URL`.
- Generate a unique production `APP_KEY`.
- Configure a production database and run `php artisan migrate --force`.
- Remove the local demo account or replace its password.
- Set secure session cookies and HTTPS at the web server or platform level.
- Run `php artisan optimize` after configuring production environment variables.

## Submission note

Add the final GitHub repository URL and hosted application URL to your learning-management-system submission after deployment. Do not commit `.env`; use `.env.example` as the configuration template.

---

Made by **Karl Ramos**.
