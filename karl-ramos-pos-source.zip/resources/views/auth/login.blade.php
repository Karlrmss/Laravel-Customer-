<x-guest-layout>
    <div class="auth-heading">
        <span class="eyebrow">Welcome back</span>
        <h2>Sign in to Karl POS</h2>
        <p>Use your authorized account to continue.</p>
    </div>
    @if (session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif
    <form class="stack-form" method="POST" action="{{ route('login') }}">
        @csrf
        <div class="field">
            <label for="email">Email address</label>
            <input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus autocomplete="username" placeholder="you@example.com">
            @error('email')<p class="field-error">{{ $message }}</p>@enderror
        </div>
        <div class="field">
            <div class="label-row"><label for="password">Password</label><a href="{{ route('password.request') }}">Forgot password?</a></div>
            <input id="password" type="password" name="password" required autocomplete="current-password" placeholder="Enter your password">
            @error('password')<p class="field-error">{{ $message }}</p>@enderror
        </div>
        <label class="check-row"><input type="checkbox" name="remember"> Keep me signed in</label>
        <button class="btn btn-primary btn-block" type="submit">Sign in securely</button>
    </form>
    <p class="auth-switch">New to Karl POS? <a href="{{ route('register') }}">Create an account</a></p>
    <div class="demo-note"><strong>Demo:</strong> admin@pos.test / password</div>
</x-guest-layout>
