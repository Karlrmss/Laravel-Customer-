<x-guest-layout>
    <div class="auth-heading">
        <span class="eyebrow">Get started</span>
        <h2>Create your account</h2>
        <p>Register for secure access to the POS console.</p>
    </div>
    <form class="stack-form" method="POST" action="{{ route('register') }}">
        @csrf
        <div class="field">
            <label for="name">Full name</label>
            <input id="name" type="text" name="name" value="{{ old('name') }}" required autofocus autocomplete="name" placeholder="Juan Dela Cruz">
            @error('name')<p class="field-error">{{ $message }}</p>@enderror
        </div>
        <div class="field">
            <label for="email">Email address</label>
            <input id="email" type="email" name="email" value="{{ old('email') }}" required autocomplete="username" placeholder="you@example.com">
            @error('email')<p class="field-error">{{ $message }}</p>@enderror
        </div>
        <div class="form-grid two">
            <div class="field">
                <label for="password">Password</label>
                <input id="password" type="password" name="password" required autocomplete="new-password" placeholder="8+ characters">
                @error('password')<p class="field-error">{{ $message }}</p>@enderror
            </div>
            <div class="field">
                <label for="password_confirmation">Confirm password</label>
                <input id="password_confirmation" type="password" name="password_confirmation" required autocomplete="new-password" placeholder="Repeat password">
            </div>
        </div>
        <button class="btn btn-primary btn-block" type="submit">Create account</button>
    </form>
    <p class="auth-switch">Already registered? <a href="{{ route('login') }}">Sign in</a></p>
</x-guest-layout>
