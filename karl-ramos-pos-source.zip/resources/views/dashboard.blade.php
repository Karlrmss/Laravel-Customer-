<x-app-layout>
    <x-slot:title>Overview</x-slot:title>
    <section class="page-heading dashboard-heading">
        <div><span class="eyebrow">{{ now()->format('l, F j') }}</span><h1>Good day, {{ explode(' ', auth()->user()->name)[0] }}.</h1><p>Here is what is happening across your POS workspace.</p></div>
        <a class="btn btn-primary" href="{{ route('customers.create') }}">+ Add customer</a>
    </section>
    <section class="stat-grid">
        <article class="stat-card"><span class="stat-icon coral">◎</span><div><small>Total customers</small><strong>{{ number_format($customerCount) }}</strong><p>All customer records</p></div></article>
        <article class="stat-card"><span class="stat-icon mint">✓</span><div><small>Active customers</small><strong>{{ number_format($activeCustomerCount) }}</strong><p>Ready for transactions</p></div></article>
        <article class="stat-card"><span class="stat-icon gold">◇</span><div><small>System users</small><strong>{{ number_format($userCount) }}</strong><p>Authorized accounts</p></div></article>
    </section>
    <section class="content-grid">
        <article class="panel">
            <div class="panel-heading"><div><h2>Recently added customers</h2><p>Your newest customer records</p></div><a href="{{ route('customers.index') }}">View all →</a></div>
            <div class="simple-list">
                @forelse ($recentCustomers as $customer)
                    <a class="list-row" href="{{ route('customers.show', $customer) }}">
                        <span class="initials">{{ collect(explode(' ', $customer->name))->map(fn ($part) => strtoupper(substr($part, 0, 1)))->take(2)->join('') }}</span>
                        <span class="list-main"><strong>{{ $customer->name }}</strong><small>{{ $customer->customer_code }} · {{ $customer->email ?: 'No email' }}</small></span>
                        <span class="badge {{ $customer->status }}">{{ ucfirst($customer->status) }}</span>
                    </a>
                @empty
                    <div class="empty-state"><strong>No customers yet</strong><p>Add the first customer to populate your workspace.</p></div>
                @endforelse
            </div>
        </article>
        <aside class="panel quick-panel">
            <div class="panel-heading"><div><h2>Quick actions</h2><p>Common account tasks</p></div></div>
            <a class="quick-link" href="{{ route('customers.create') }}"><span>+</span><div><strong>New customer</strong><small>Create a customer record</small></div><b>→</b></a>
            <a class="quick-link" href="{{ route('users.create') }}"><span>+</span><div><strong>New system user</strong><small>Grant account access</small></div><b>→</b></a>
            <a class="quick-link" href="{{ route('profile.edit') }}"><span>↗</span><div><strong>Account settings</strong><small>Update your profile</small></div><b>→</b></a>
        </aside>
    </section>
</x-app-layout>
