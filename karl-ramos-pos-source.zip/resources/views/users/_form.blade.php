<div class="form-grid two">
    <div class="field"><label for="name">Full name</label><input id="name" name="name" value="{{ old('name', $user->name) }}" required placeholder="Full name">@error('name')<p class="field-error">{{ $message }}</p>@enderror</div>
    <div class="field"><label for="email">Email address</label><input id="email" type="email" name="email" value="{{ old('email', $user->email) }}" required placeholder="user@example.com">@error('email')<p class="field-error">{{ $message }}</p>@enderror</div>
    <div class="field"><label for="password">Password @if ($user->exists)<span class="optional">(leave blank to keep current)</span>@endif</label><input id="password" type="password" name="password" {{ $user->exists ? '' : 'required' }} autocomplete="new-password" placeholder="At least 8 characters">@error('password')<p class="field-error">{{ $message }}</p>@enderror</div>
    <div class="field"><label for="password_confirmation">Confirm password</label><input id="password_confirmation" type="password" name="password_confirmation" {{ $user->exists ? '' : 'required' }} autocomplete="new-password" placeholder="Repeat password"></div>
</div>
