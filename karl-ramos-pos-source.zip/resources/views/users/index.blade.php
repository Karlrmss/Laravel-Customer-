<x-app-layout>
    <x-slot:title>Users</x-slot:title>
    <section class="page-heading"><div><span class="eyebrow">Access management</span><h1>System users</h1><p>Manage the people authorized to use the POS console.</p></div><a class="btn btn-primary" href="{{ route('users.create') }}">+ Add user</a></section>
    <section class="panel table-panel">
        <div class="table-toolbar"><form class="search-form" method="GET" action="{{ route('users.index') }}"><input type="search" name="search" value="{{ $search }}" placeholder="Search name or email"><button class="btn btn-secondary" type="submit">Search</button></form><span class="record-count">{{ $users->total() }} {{ Str::plural('account', $users->total()) }}</span></div>
        <div class="table-wrap"><table><thead><tr><th>User</th><th>Access</th><th>Joined</th><th class="actions-col">Actions</th></tr></thead><tbody>
            @forelse ($users as $user)
                <tr><td><div class="person-cell"><span class="initials user">{{ strtoupper(substr($user->name, 0, 2)) }}</span><div><strong>{{ $user->name }}</strong><small>{{ $user->email }}</small></div></div></td><td><span class="badge active">Authorized</span>@if (auth()->id() === $user->id)<small class="you-label">Current account</small>@endif</td><td>{{ $user->created_at->format('M d, Y') }}</td><td class="actions"><a href="{{ route('users.show', $user) }}">View</a><a href="{{ route('users.edit', $user) }}">Edit</a>@if (auth()->id() !== $user->id)<form method="POST" action="{{ route('users.destroy', $user) }}" onsubmit="return confirm('Delete this user account?')">@csrf @method('DELETE')<button type="submit">Delete</button></form>@endif</td></tr>
            @empty<tr><td colspan="4"><div class="empty-state"><strong>No matching users</strong><p>Try another search or create a user account.</p></div></td></tr>@endforelse
        </tbody></table></div>
        @if ($users->hasPages())<div class="pagination"><span>Page {{ $users->currentPage() }} of {{ $users->lastPage() }}</span><div>@if ($users->onFirstPage())<span class="btn btn-secondary disabled">Previous</span>@else<a class="btn btn-secondary" href="{{ $users->previousPageUrl() }}">Previous</a>@endif @if ($users->hasMorePages())<a class="btn btn-secondary" href="{{ $users->nextPageUrl() }}">Next</a>@else<span class="btn btn-secondary disabled">Next</span>@endif</div></div>@endif
    </section>
</x-app-layout>
