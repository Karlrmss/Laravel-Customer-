<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Karl POS · Customer & User Management</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body class="landing-body">
    <header class="landing-nav">
        <a class="brand" href="{{ route('home') }}"><span class="brand-mark">KR</span><span>Karl POS</span></a>
        <nav>
            @auth
                <a class="btn btn-primary" href="{{ route('dashboard') }}">Open dashboard</a>
            @else
                <a class="btn btn-ghost" href="{{ route('login') }}">Sign in</a>
                <a class="btn btn-primary" href="{{ route('register') }}">Create account</a>
            @endauth
        </nav>
    </header>
    <main class="hero">
        <div class="hero-copy">
            <span class="eyebrow">Laravel resource management</span>
            <h1>Keep every customer relationship <em>in clear view.</em></h1>
            <p>A focused POS account console with conventional CRUD workflows, secure Breeze authentication, and a clean experience for daily operations.</p>
            <div class="hero-actions">
                <a class="btn btn-primary btn-lg" href="{{ auth()->check() ? route('dashboard') : route('login') }}">Manage accounts <span>→</span></a>
                <span class="secure-note">Protected by Laravel auth middleware</span>
            </div>
        </div>
        <div class="hero-visual" aria-label="Application preview">
            <div class="preview-window">
                <div class="preview-top"><i></i><i></i><i></i><span>Karl POS / Overview</span></div>
                <div class="preview-body">
                    <div class="preview-sidebar"><b>KR</b><span class="on"></span><span></span><span></span></div>
                    <div class="preview-main">
                        <div class="preview-heading"><div><small>GOOD DAY, KARL</small><strong>Business overview</strong></div><button>+ New customer</button></div>
                        <div class="preview-stats"><div><small>Customers</small><strong>248</strong></div><div><small>Active</small><strong>231</strong></div><div><small>Users</small><strong>12</strong></div></div>
                        <div class="preview-table"><div class="preview-row head"><span>Customer</span><span>Status</span></div><div class="preview-row"><span>AR&nbsp; Ana Reyes</span><b>Active</b></div><div class="preview-row"><span>MC&nbsp; Marco Cruz</span><b>Active</b></div><div class="preview-row"><span>JS&nbsp; Jamie Santos</span><b>Active</b></div></div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer class="landing-footer"><span>Built by <strong>Karl Ramos</strong></span><span>Laravel 11 · Breeze · Resource Controllers</span></footer>
</body>
</html>
