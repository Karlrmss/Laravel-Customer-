<x-app-layout>
    <x-slot:title>Customers</x-slot:title>
    <section class="page-heading"><div><span class="eyebrow">Account management</span><h1>Customers</h1><p>Create, review, update, and manage customer records.</p></div><a class="btn btn-primary" href="{{ route('customers.create') }}">+ Add customer</a></section>
    <section class="panel table-panel">
        <div class="table-toolbar">
            <form class="search-form" method="GET" action="{{ route('customers.index') }}"><input type="search" name="search" value="{{ $search }}" placeholder="Search code, name, email, or phone"><button class="btn btn-secondary" type="submit">Search</button></form>
            <span class="record-count">{{ $customers->total() }} {{ Str::plural('record', $customers->total()) }}</span>
        </div>
        <div class="table-wrap"><table><thead><tr><th>Customer</th><th>Contact</th><th>Status</th><th>Created</th><th class="actions-col">Actions</th></tr></thead><tbody>
            @forelse ($customers as $customer)
                <tr><td><div class="person-cell"><span class="initials">{{ strtoupper(substr($customer->name, 0, 2)) }}</span><div><strong>{{ $customer->name }}</strong><small>{{ $customer->customer_code }}</small></div></div></td><td><strong class="normal">{{ $customer->email ?: 'No email' }}</strong><small>{{ $customer->phone ?: 'No phone' }}</small></td><td><span class="badge {{ $customer->status }}">{{ ucfirst($customer->status) }}</span></td><td>{{ $customer->created_at->format('M d, Y') }}</td><td class="actions"><a href="{{ route('customers.show', $customer) }}">View</a><a href="{{ route('customers.edit', $customer) }}">Edit</a><form method="POST" action="{{ route('customers.destroy', $customer) }}" onsubmit="return confirm('Delete this customer?')">@csrf @method('DELETE')<button type="submit">Delete</button></form></td></tr>
            @empty
                <tr><td colspan="5"><div class="empty-state"><strong>No matching customers</strong><p>Try another search or create a customer account.</p></div></td></tr>
            @endforelse
        </tbody></table></div>
        @if ($customers->hasPages())<div class="pagination"><span>Page {{ $customers->currentPage() }} of {{ $customers->lastPage() }}</span><div>@if ($customers->onFirstPage())<span class="btn btn-secondary disabled">Previous</span>@else<a class="btn btn-secondary" href="{{ $customers->previousPageUrl() }}">Previous</a>@endif @if ($customers->hasMorePages())<a class="btn btn-secondary" href="{{ $customers->nextPageUrl() }}">Next</a>@else<span class="btn btn-secondary disabled">Next</span>@endif</div></div>@endif
    </section>
</x-app-layout>
