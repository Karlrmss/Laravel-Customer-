<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Account access · Karl POS</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body class="auth-body">
    <main class="auth-shell">
        <section class="auth-brand-panel">
            <a class="brand brand-light" href="{{ route('home') }}">
                <span class="brand-mark">KR</span>
                <span>Karl POS</span>
            </a>
            <div class="auth-pitch">
                <span class="eyebrow">Secure workspace</span>
                <h1>One place for every customer and account.</h1>
                <p>Resourceful, organized, and protected by Laravel Breeze authentication.</p>
            </div>
            <p class="auth-credit">Designed and developed by Karl Ramos</p>
        </section>
        <section class="auth-form-panel">
            <div class="auth-card">{{ $slot }}</div>
        </section>
    </main>
</body>
</html>
