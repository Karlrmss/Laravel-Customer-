<header class="topbar">
    <div class="topbar-inner">
        <a class="brand" href="{{ route('dashboard') }}">
            <span class="brand-mark">KR</span>
            <span class="brand-copy"><strong>Karl POS</strong><small>Account Console</small></span>
        </a>
        <button class="nav-toggle" type="button" data-nav-toggle aria-label="Open navigation">☰</button>
        <nav class="main-nav" data-mobile-nav aria-label="Primary navigation">
            <a class="{{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}">Overview</a>
            <a class="{{ request()->routeIs('customers.*') ? 'active' : '' }}" href="{{ route('customers.index') }}">Customers</a>
            <a class="{{ request()->routeIs('users.*') ? 'active' : '' }}" href="{{ route('users.index') }}">Users</a>
        </nav>
        <div class="user-menu">
            <div class="user-avatar">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</div>
            <div class="user-copy"><strong>{{ auth()->user()->name }}</strong><small>{{ auth()->user()->email }}</small></div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="btn btn-ghost btn-sm" type="submit">Sign out</button>
            </form>
        </div>
    </div>
</header>
