<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? 'Karl POS' }} · Karl POS</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body class="app-body">
    @include('layouts.navigation')
    <main class="main-content">
        <div class="page-container">
            @if (session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif
            @if (session('error'))
                <div class="alert alert-error">{{ session('error') }}</div>
            @endif
            {{ $slot }}
        </div>
    </main>
    <script>
        document.querySelector('[data-nav-toggle]')?.addEventListener('click', function () {
            document.querySelector('[data-mobile-nav]')?.classList.toggle('is-open');
        });
    </script>
</body>
</html>
