<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController;
use App\Models\Customer;
use App\Models\User;
use Illuminate\Support\Facades\Route;

Route::view('/', 'welcome')->name('home');

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard', [
            'customerCount' => Customer::count(),
            'activeCustomerCount' => Customer::where('status', 'active')->count(),
            'userCount' => User::count(),
            'recentCustomers' => Customer::latest()->take(5)->get(),
        ]);
    })->name('dashboard');

    // One resource registration provides all seven conventional CRUD routes.
    Route::resource('customers', CustomerController::class);
    Route::resource('users', UserController::class);

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
