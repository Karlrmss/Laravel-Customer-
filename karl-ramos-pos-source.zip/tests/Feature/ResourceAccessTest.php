<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class ResourceAccessTest extends TestCase
{
    use RefreshDatabase;

    public function test_guests_are_redirected_from_customer_and_user_resources(): void
    {
        $this->get(route('customers.index'))->assertRedirect(route('login'));
        $this->get(route('customers.create'))->assertRedirect(route('login'));
        $this->get(route('users.index'))->assertRedirect(route('login'));
        $this->get(route('users.create'))->assertRedirect(route('login'));
    }

    public function test_authenticated_user_can_reach_protected_pages(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->get(route('dashboard'))->assertOk();
        $this->actingAs($user)->get(route('customers.index'))->assertOk();
        $this->actingAs($user)->get(route('users.index'))->assertOk();
    }

    public function test_authenticated_user_can_complete_customer_crud(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->post(route('customers.store'), [
            'customer_code' => 'CUS-TEST',
            'name' => 'Test Customer',
            'email' => 'customer@example.com',
            'phone' => '09171234567',
            'address' => 'Manila',
            'status' => 'active',
        ])->assertRedirect(route('customers.index'));

        $customer = Customer::where('customer_code', 'CUS-TEST')->firstOrFail();

        $this->actingAs($user)->put(route('customers.update', $customer), [
            'customer_code' => 'CUS-TEST',
            'name' => 'Updated Customer',
            'email' => 'customer@example.com',
            'phone' => '09171234567',
            'address' => 'Quezon City',
            'status' => 'inactive',
        ])->assertRedirect(route('customers.index'));

        $this->assertDatabaseHas('customers', ['name' => 'Updated Customer', 'status' => 'inactive']);

        $this->actingAs($user)->delete(route('customers.destroy', $customer))
            ->assertRedirect(route('customers.index'));

        $this->assertDatabaseMissing('customers', ['id' => $customer->id]);
    }

    public function test_authenticated_user_can_create_a_secure_user_account(): void
    {
        $admin = User::factory()->create();

        $this->actingAs($admin)->post(route('users.store'), [
            'name' => 'POS Operator',
            'email' => 'operator@example.com',
            'password' => 'SecurePass123!',
            'password_confirmation' => 'SecurePass123!',
        ])->assertRedirect(route('users.index'));

        $operator = User::where('email', 'operator@example.com')->firstOrFail();

        $this->assertTrue(Hash::check('SecurePass123!', $operator->password));
        $this->assertNotSame('SecurePass123!', $operator->password);
    }

    public function test_current_user_cannot_delete_their_own_account_from_user_management(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->delete(route('users.destroy', $user))
            ->assertSessionHas('error');

        $this->assertDatabaseHas('users', ['id' => $user->id]);
    }
}
